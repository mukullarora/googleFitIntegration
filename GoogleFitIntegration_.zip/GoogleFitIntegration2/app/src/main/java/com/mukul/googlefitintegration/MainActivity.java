package com.mukul.googlefitintegration;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.fitness.request.DataReadRequest;
import com.google.android.gms.fitness.Fitness;
import com.google.android.gms.fitness.FitnessOptions;
import com.google.android.gms.fitness.data.DataType;


import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.TimeUnit;


public class MainActivity extends Activity {

    private static final int GOOGLE_FIT_PERMISSIONS_REQUEST_CODE = 1001;
    private static final FitnessOptions fitnessOptions = FitnessOptions.builder()
            .addDataType(DataType.TYPE_STEP_COUNT_DELTA, FitnessOptions.ACCESS_READ)
            .build();

//    private Button button;
////    private DataReadRequest readRequest;
////    private GoogleSignInAccount account;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        View stepCountTextView = findViewById(R.id.stepCountTextView);
        Button refreshButton = findViewById(R.id.refreshButton);
        refreshButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

        View button = findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                retrieveStepCountData();
                requestGoogleFitPermission();

            }

        });
    }

    private void requestGoogleFitPermission() {
        GoogleSignInAccount account = GoogleSignIn.getAccountForExtension(this, fitnessOptions);

        if (!GoogleSignIn.hasPermissions(account, fitnessOptions)) {
            GoogleSignIn.requestPermissions(
                    this,
                    GOOGLE_FIT_PERMISSIONS_REQUEST_CODE,
                    account,
                    fitnessOptions);
        } else {
            // The user has already granted permission. You can proceed with step count retrieval.
            retrieveStepCountData();
        }
    }


    private void retrieveStepCountData() {
        // Set the time range for the past 24 hours
        Calendar calendar = Calendar.getInstance();
        Date endTime = calendar.getTime();
        calendar.add(Calendar.DAY_OF_YEAR, -1);
        Date startTime = calendar.getTime();

        // Build the data request
        DataReadRequest readRequest = new DataReadRequest.Builder()
                .aggregate(DataType.TYPE_STEP_COUNT_DELTA, DataType.AGGREGATE_STEP_COUNT_DELTA)
                .bucketByTime(1, TimeUnit.DAYS)
                .setTimeRange(startTime.getTime(), endTime.getTime(), TimeUnit.MILLISECONDS)
                .build();

        // Get the Google Sign-In account
        GoogleSignInAccount account = GoogleSignIn.getAccountForExtension(this, fitnessOptions);

        // Retrieve the step count data
        Fitness.getHistoryClient(this, account)
                .readData(readRequest)
                .addOnSuccessListener(dataReadResponse -> {
                    // Process the step count data
                    // You can display it in a TextView or perform any other required actions


                    // For simplicity, let's just display the total step count
                    int stepCount = 0;
                    for (com.google.android.gms.fitness.data.DataSet dataSet : dataReadResponse.getDataSets()) {
                        for (com.google.android.gms.fitness.data.DataPoint dataPoint : dataSet.getDataPoints()) {
                            for (com.google.android.gms.fitness.data.Field field : dataPoint.getDataType().getFields()) {
                                int steps = dataPoint.getValue(field).asInt();
                                stepCount += steps;
                            }
                        }
                    }

                    // Display the step count
                    TextView stepCountTextView = findViewById(R.id.stepCountTextView);
                    stepCountTextView.setText("Step Count: " + stepCount);
                })
                .addOnFailureListener(e -> {
                    // Handle the failure case
                    Toast.makeText(this, "Failed to retrieve step count data", Toast.LENGTH_SHORT).show();
                });
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == GOOGLE_FIT_PERMISSIONS_REQUEST_CODE) {
            if (resultCode == Activity.RESULT_OK) {
                // Permission granted, proceed with step count retrieval.
                retrieveStepCountData();
            } else {
                // Permission denied, handle accordingly.
                Toast.makeText(this, "Google Fit permission denied.", Toast.LENGTH_SHORT).show();
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }
}